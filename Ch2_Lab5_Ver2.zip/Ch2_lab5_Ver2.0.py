# Python 3.8
# Win 10 64 bit
# MySQL server version: 5.7.17

import re
from urllib.request import urlopen
from bs4 import BeautifulSoup as bs
import mysql.connector
from multiprocessing import Pool
from multiprocessing import current_process
import getpass

# Function to get html data

def get_html1(url):
    html_str = ''
    flag_try = 0    
    while html_str == '' and flag_try <=4:
        try:
            new_html = urlopen(url, timeout=10)
            html_str = str(new_html.read(), encoding='utf-8')
        except Exception:
            print('error download')
            flag_try = flag_try + 1
    return html_str

def get_dirtrain_list(url):
    print(current_process().name, 'processing', url)
    dirtrain_dict = {}
    ahtml = get_html1(url)
    bs_str = bs(ahtml, 'html.parser')
    lst_div = bs_str.findAll('div', {'class':'course_groups-box'})
    if len(lst_div)!=0:
        lst_group = re.findall(r'\d">([\s\S]*?)</a', str(lst_div[0]))
    else:
        lst_group = []
    return lst_group


if __name__ == '__main__':

# Creare database and tables block

    try:
        password = getpass.getpass('Enter password of root_user (nothing chars will not visible, even "*"): ')
        mydb = mysql.connector.connect(host='localhost', user='root', password=password)
        cur = mydb.cursor()
        cur.execute("CREATE DATABASE IF NOT EXISTS OpenEdu_Courses")
        mydb.commit()
    except Exception as e:
        print('Error access to DataBase:', e)
        exit(0)

    #print(mydb)
    #input('Press "Enter" to continue ...')
    #print('')


    print('')
    print('Database "OpenEdu_Courses" is created.')
    print('For check is ran the request: "SHOW DATABASES"')
    print('Result:')
    print('________________________')
    cur.execute("SHOW DATABASES")
    for i in cur:
        print(i)
    print('________________________')
    input('Press "Enter" to continue ...')
    print('')


    try:
        cur.execute("USE OpenEdu_Courses")
        cur.execute("""CREATE TABLE courses (id_course INT PRIMARY KEY, name_course VARCHAR(255) CHARACTER SET utf8mb4, 
                    url_course VARCHAR(255) CHARACTER SET utf8mb4)""")
        cur.execute("""CREATE TABLE dir_train (id_DirTrain INT AUTO_INCREMENT PRIMARY KEY, 
                    name_DirTrain VARCHAR(255) CHARACTER SET utf8mb4)""")
        mydb.commit()
    except Exception as e:
        print('Error access to DataBase:', e)
        exit(0)


    print('')
    print('Tables "courses" and "dir_train" are created.')
    print('For check is ran the request: "SHOW TABLES"')
    print('Result:')
    print('________________________')
    cur.execute("SHOW TABLES")
    for i in cur:
        print(i)
    print('________________________')
    input('Press "Enter" to continue ...')
    print('')



    url = 'https://openedu.ru/course/'

# Getting full courses data

    ahtml = get_html1(url)
    lst = re.findall(r'COURSES\s*=\s*(.+);\n', ahtml)
    if len(lst)!=0:
        lst1 = re.findall(r'("\d+":\s*[\s\S]*?),\s*"c', str(lst[0]).strip())
    else:
        lst1 =[]
    list_for_db = []
    url_list =[]

    
# Getting id, name and url of each course. Insert these data in to the table "courses".

    sql = "INSERT INTO courses (id_course, name_course, url_course) VALUES(%s, %s, %s)"
    for el in lst1:
        idCourse = int(re.findall(r'"(\d+)":\s*{', el)[0])
        nameCourse = re.findall(r'"title":\s*"([\s\S]*?)",\s*"', el)[0]
        urlCourse =url + re.findall(r'"url":\s*"/course/([\s\S]*?)"', el)[0]
        list_for_db.append([idCourse, nameCourse, urlCourse])
        url_list.append(urlCourse)
        val = (idCourse, nameCourse, urlCourse)
        cur.execute(sql, val)
        mydb.commit()


    print('')
    print('Tables "courses" is filled.')
    print('For check is ran the request1: "SELECT * FROM courses WHERE id_course >0 and id_course<50"')
    print('Result:')
    print('________________________')
    cur.execute("SELECT * FROM courses WHERE id_course >0 and id_course<10")
    for i in cur:
        print(i)
    print('________________________')
    input('Press "Enter" to continue ...')
    print('')



# Getting train directions for each course. Creating dictionary of train directions.



    fl1 = 0
    dirtrain_dict = {}
    lst_group = []
    pool = Pool(10)
    lst_group = lst_group + list(pool.map(get_dirtrain_list, url_list))
    for elem in lst_group:
            for elem1 in elem:
                dirtrain_dict[elem1] = 0


# Insert train directions data in to table "dir_train"
    
    sql = "INSERT INTO dir_train (name_dirtrain) VALUES(%s)"
    for el in dirtrain_dict:
        val = (el,)
        cur.execute(sql, val)
        mydb.commit()
    print('')
    print('Table "dir_train" is filled.')
    print('For check is ran the request1: "SELECT * FROM dir_train WHERE id_dirTrain >0 and id_dirTrain<10"')
    print('Result:')
    print('________________________')
    cur.execute("SELECT * FROM dir_train WHERE id_dirTrain >0 and id_dirTrain<10")
    for i in cur:
        print(i)
    print('________________________')
    print('Programm in ended.')
